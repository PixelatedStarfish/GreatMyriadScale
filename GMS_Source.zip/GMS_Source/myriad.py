#This code was written without genAI because I am a big boy. I know, this is still python, not C or assembly, but while I am a big boy, I do not want to go crazy either. C would give me more control over memory, but python is certainly good enough here.

#This program is a fork of Conway's Illion Converter by kyoda
#The Great Myriad Scale is created by Andrew

#TODO finish counter function

import sys
import time

UNIT = ['', 'prot', 'deut', 'trit', 'tet','pempt', 'hect', 'hebdom', 'ogd', 'enat', 'decat', 'hendecat', 'dodecat'] #11 and 12 demand edge cases in the form of 'hendecat' and 'dodecat'
TEN = ['', 'decat', 'icost', 'tricost', 'tesserecost', 'pentecost','hexecost', 'hebdomecost', 'ogdoecost', 'enatecost'] #fudging the greek a bit, but this is reasonably accurate
HUND = ['hecatost', 'protehecatost', 'deuterehecatost', 'tritehecatost', 'tesserehecatost', 'pentehecatost', 'hexehecatost', 'hebdomehecatost', 'ogdoehecatost', 'enatehecatost', 'decatehecatost', 'hendecatehecatost', 'dodecatehecatost'] # items [1] to [12] are appended to the front of hecatost, after the unit is rounding of an "n-hecatost"
GREAT = ['great', 'greater']

DISPLAY = True
SUFFIX = "yriad" 
MAX = 3000
THOUSANDS = False

def main(arg = "", th = True, display = True):
    sys.set_int_max_str_digits(4300)
    global DISPLAY
    global THOUSANDS
    DISPLAY = display #don't print anything if display is false
    THOUSANDS = th

    #command line arg
    if len(sys.argv) > 1:
        return parseInput(sys.argv[1])

    if not arg == "": #main is called from somehwere else
        return parseInput(arg)
    dprint("\nThis program is a proof of concept for the Great Myriad Scale.\nThis scale names large numbers with myriads, rather than millions.\nYou can find more details on that in the readme.\nThis program is based on \"Conway's illion Converter\" by kyoda.")
    PickNumberLoop()

def dprint(s = ""):
    global DISPLAY
    if DISPLAY:
        print(s)

def parseInput(i):
    i = i.replace(" ", "")

    args = i.split(":")

    if len(args) < 2:
        return printTenPower(i)
    if len(args) == 2:
        return list(args[0], args[1])
    if len(args) == 3:
        return list(args[0], args[1], args[2])
    if len(args) > 3:
        return list(args[0], args[1], args[2], args[3])

def PickNumberLoop():
    i = "Lorem Ipsum"
    while (not i == ""):
        i = input("\nGive a power of ten (10^n), and get its name in the Great Myriad Scale.\nUse colons to list (start:stop:skip).\n> ")
        parseInput(i)
        dprint()


def list(start = 1, end = 1, skip = 1):

    try:
        end = int(end)
        skip = int(skip)
        start = int(start)
    except ValueError:
        print ("Value Error")
        return ""
   
    i = start
    while i <= end:
        #dprint(i)
         
        printTenPower(str(i))
        dprint()
        i += skip
        time.sleep(.3)

def printTenPower(e):
    th = ""
    global THOUSANDS
    if THOUSANDS:
        th = "One Thousand"
    else:
        th = "Ten Hundred"


    #this was originally written for powers of the myriad
    try:
        tenners = ["One", "Ten", "One Hundred", th] #10^5 is always ten myriad
        out = tenners[int(e) % 4]
    except ValueError:
        dprint("Value Error")
        return ""

    if int(e) < 0:
        dprint("Please use non-negative integers.")
        return
    i = int(e) // 4
    m =  myriad(i)
    if not m == "" and int(i) > 9999999:  #seven nines
        m = greatsTruncator(m)

    if (not m == ""):
        out = (out + " " + m).title()

    dprint("\n10^" + str(e) + "\n-> \"" + str(out) + "\"")
    return out

def greatsTruncator(m):
    #its linear, but the "greats" can just be tallied up and trucated accordingly
    #unfortunately this code is kind of fragile and does not play nicely with refactoring
    #so it has to go in its own little function
    headIndex = 0
    writingtoOut = True
    c = 0
    greats = 0
    g = GREAT[0][0]
    r = GREAT[0][1]
    o = ""
    while c < len(m) - 1:
        if m[c] == g and m[c+1] == r:
            greats += 1
            if writingtoOut:
                headIndex = c
                writingtoOut = False
        if m[c] == " " and not m[c+1] == g:
            if greats == 1:
                o += GREAT[0]
            if greats > 1:
                global THOUSANDS
                o += counter(greats, THOUSANDS).strip("-") + "-fold " + GREAT[1] #adverbial form english cardinals with "greater" indicates a number of greats

            greats = 0
            writingtoOut = True
        if writingtoOut:
            o += m[c]
        c = c + 1
    return o + "d"


def counter(i, th = False, stringInput = False):

    if stringInput: #if the input is a string, validate it for testing
        try:
           i = int(i)
        except ValueError:
            try:
                i = int(i.replace(" ", "").replace(".", "").replace(",", ""))
            except ValueError:
               return "Silly bean, pick a number!"

    i = int(i)
    if i < 1:
        return ""
    out = ""

    #see else case
    c = 0 
    modulus = 0 
    ##

    Units = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"]
    Tens = ["", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]

    if i < 21:
        return "-" + Units[i] 
    if i < 100:
        return "-" +  Tens[i // 10] + counter(i % 10, th) 
    if  th and  i > 999 and i < 100000 and i % 1000 == 0: #if th is true, use two thousand instead of twenty hundred (from 1 to 99 thousand)
        #print(i // 1000, i % 1000)
        return counter(i // 1000, th) + "-thousand" + counter(i % 1000, th) 
    if i < 10000:
        return counter(i // 100, th) + "-hundred" + counter(i % 100, th)
    while i > 9999: 
        modulus = (i % 10000) 
        i = i // 10000

        # I think the way to do this is to have cases for individual groups of four digits.
        caseA = (modulus > 0 and i > 9999) #1234, 2300, 0001; any group of only four digits, that is non zero
        caseB = (modulus == 0 and i > 9999) # 0000; all zeroes, nothing else
        caseC = (i < 10000 and modulus > 0) # 11, or 100; a group of Most Significant Digits that is of four or less digits
        caseD = (i < 10000 and modulus == 0) #edge case on c
        # that should cover everything  

        if caseA:
           # print("Case A:")
           # print (i, modulus, c)
            out =  counter(modulus, th) + "-" + myriad(c) + out
        if caseB:
           # print("Case B:")
           # print (i, modulus, c)
            c += 1
            continue
        if caseC: 
           # print("Case C:")
           # print (i, modulus, c)
            out =  "-" + counter(i, th) + "-" + myriad(c +1) + counter(modulus, th) + "-" + myriad(c) + out
        if caseD: 
           # print("Case D:")
            c += 1
           # print (i, modulus, c)
            out =  "-" + counter(i, th) + "-" + myriad(c) + out
    
        c += 1

    return out

def myriad(n):
    global SUFFIX
    suffix = SUFFIX
    #input sanitization

    try:
        n = int(n) #the myriad function can handle negative integers
        if n < 0:
            n = n * -1
            suffix = suffix + "th"
    except ValueError:
        #dprint(' an error :(')
        return ""

    global THOUSANDS
    if n > 10 ** MAX:
        return "Big-Enough-For-This-Implementation-yriad"
    #edge cases
    if n == 0:
        return '' #one
    if n == 1:
            return 'myriad'
 

    #end of edge cases
    return str(base(n)) + suffix

def base(n):
    if n < 12 or n == 12: #11 and 12 are edge cases that need to be treated like units, so 10 is also in the units. 'Decat' is used twice.
        return UNIT[n]
    if n < 100:
        t = n // 10
        m = n % 10
        if m == 0:
            return TEN[t]
        if (m < 8): #vowels matter for the 10's. You want "conta", "cato", and "coso", but not "oo" "oe" or "th" to keep demoninations readble. 10000^17 is decato-hebdomiad 10000^18 is decat-ogdiad.
            return TEN[t] + "o" + base(m)

        else:
            return TEN[t] +  base(m)

    if n < 1000:
        t = n // 100
        m = n % 100
        if t == 1:
            return HUND[0] + base(m)

        #edge case land
        if t % 10 == 8 or t % 10 == 9:
            return base(t - (t % 10))  + HUND[t % 10] + base(m)   
        edge = t % 100
        if edge < 13  and t - edge > 0:
            return base(t - edge) + "e" + HUND[t % 10] + base(m)
        if edge < 13 and t - edge == 0:
            return HUND[t % 20] + base(m)

        #set the least sig digit of t to 0, pass the actual value of that digit to the hund arr (with edge cases in the edge case land)
        return base(t - (t % 10)) + "e" + HUND[t % 10] + base(n % 100)  

    if n < 10000:
        t = n // 100

        #edge case land
        if t % 10 == 8 or t % 10 == 9:
            return base(t - (t % 10))  + HUND[t % 10] + base(n % 100)
        edge = t % 100
        if edge < 13  and t - edge > 0:
            return base(t - edge) + "e" + HUND[t % 10] + base(n % 100)  
        if edge < 13  and t - edge == 0:
            return HUND[t % 20] + base(n % 100) 
        

        #set the least sig digit of t to 0, pass the actual value of digit to the hund arr (with edge cases in the edge case land)
        return base(t - (t % 10)) + "e" + HUND[t % 10] + base(n % 100)

    #if n < 100000000: # great myriad to great great myriad or two-fold greater myriad
    else:
        g = n // 10000
        m = n % 10000
        if g == 1 and m == 0:
            return GREAT[0] + " m"
        if g == 1 and m > 0:
            return myriad(m) + " " + GREAT[0] + " m"
        if g > 1 and m == 0:
            #if you actually try to track the stack calls by printing base(g) before return there's a lot more than I expected. It still outputs the correct number of "greats"
            #dprint(str(n) + "," + str(g) + " -> " + base(g))
            return GREAT[0] + " " + base(g)
        if g > 1 and m > 0:
            return myriad(m % 10000) + " " + GREAT[0] + " " + base(g)

if __name__ == "__main__":
    main()

