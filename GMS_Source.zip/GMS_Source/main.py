
import myriad
import million
import tables
import sys
import os
import time

THOUSANDS = False

def main(arg = "", display = True):

    #tables.main()

    #command line arg
    if len(sys.argv) > 1:
        return parseInput(sys.argv[1])
    #main is called from somehwere else
    if not arg == "":
        return parseInput(arg)
    PickNumberLoop()


def parseInput(i):
    global THOUSANDS

    if (i == ""):
        return ""
    i = i.replace(" ", "")[0] #get a number

    if (i == "1"):
        myriad.main()
        return
    if (i == "2"):
        million.main()
        return
    if (i == "3"):
        NumberNamer(THOUSANDS)
        return
    if (i == "4"):
        tables.main()
        return
    if (i == "5"):
        Epoch()
    if (i == "6"):
        THOUSANDS = not THOUSANDS
        print("Toggled")


    else:
        print("Silly bean, pick a number!\n")
    return


def Epoch():
    while (True):
        print("It has been\n*" + myriad.counter(time.time(), True).strip("-") + "* seconds\nsince midnight of January first 1970\n")
        time.sleep(1)


def PickNumberLoop():
    i = "Lorem Ipsum"
    tables.main()
    while (not i == ""):
        global THOUSANDS
        b = ""
        if THOUSANDS:
            b = "Toggle to \"Ten Hundreds\""
        else:
            b = "Toggle to \"Thousands\""

        i = input("Select an option:\n1. Generate Myriads\n2. Generate Millions\n3. Number Namer\n4. Tables (Quick Help)\n5. Epoch Mode\n6. " + b + "\n> ")
        parseInput(i)
        print()


def NumberNamer(th = True):
        while True:
            i = input("\nGive me a number from one to forever. I'll tell you its name, in myriads, clever.\n> ") #I was going to do start:stop:skip but it broke the compiler. (?!) "timer.sleep() is not a function. Did you mean timer.sleep()"? The 'p' in sleep was present, but not highlighted in red. The error highlight just skipped it.   
            if i == "":
                return 
            try:
                print(myriad.counter(i, th, True).strip("-"))
            except ValueError:
                print("\"" + str(i) +"\"? What do you mean? Silly bean!")

if __name__ == '__main__':
    main()        
