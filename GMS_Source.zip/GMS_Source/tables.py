from tabulate import tabulate
import myriad
import million


def main():
    s = '''
\n-Great Myriad Scale-

So, in the United States, a system called the short scale is used to count, based on powers of one thousand.
In parts of Europe, the long scale is used, based on powers of one million.
These scales use Latin numerals to name large numbers, but the names of very large numbers can get hard to read.
So, the Great Myriad Scale uses the myriad (ten to the fourth power) and combines it with Greek numerals, instead.
For example the square of myriad is called a 'duetyriad' from 'dueteros myriad' or 'second myriad'. 
The deutyriad is written as '1,0000,0000' such that digits are written in groups of four.
See the tables below, where 'e' denotes a power of ten:
    '''

    print(s)

    print(getMyriadTable())
    #print(getScaleTable(1))
    if not input("\nThis implementation supports millions, myriads, thousands, and ten-hundreds.\nIt also has a Unix Clock that should run fine until at least 2038.\nPlease check the README, html page, or github page for more.\nPress enter to get to tinkering. Enter \"I like tables.\" (or anything else) for more tables\n> ") == "":
        printBigTables()
    


def printBigTables():
    print("\n-Please zoom out or enlarge your window for proper formatting-\n")
    input("Push enter to continue\n> ")
    print(getMyriadTable())
    print(getScaleTable(2))
    if not input("\nPress enter to get to tinkering. Enter \"I like tables.\" (or anything else) for even more tables\n> ") == "":
        print(getScaleTableShort(4))
        print(getScaleTableLong(4))
        input("Press enter to continue\n> ")



def genericTable():
    # Column headers
    headers = ["Name", "Age", "Profession"]
    # Data for the table
    data =  [["Alice", "24", "Engineer"],
            ["Bob", "27", "Designer"],
            ["Charlie", "22", "Artist"]]

    # Generate Markdown table
    markdown_table = tabulate(data, headers, tablefmt="pipe", stralign="center")
    print(markdown_table)


def getMyriadTable():
    headers = ["e", "Name", "e", "Name", "e", "Name"]
    data = [["4", "<m>", "48", "<m>", "120", "<m>"],
            ["8", "<m>", "52", "<m>", "160", "<m>"],
            ["12", "<m>", "56", "<m>", "200", "<m>"],
            ["16", "<m>", "60", "<m>", "240", "<m>"],
            ["20", "<m>", "64", "<m>", "280", "<m>"],
            ["24", "<m>", "68", "<m>", "320", "<m>"],
            ["28", "<m>", "72", "<m>", "360", "<m>"],
            ["32", "<m>", "76", "<m>", "400", "<m>"],
            ["36", "<m>", "80", "<m>", "2000", "<m>"],
            ["40", "<m>", "84", "<m>", "4000", "<m>"],
            ["44", "<m>", "88", "<m>", "40000", "<m>"]]

    return tablegen(headers, data, "The Myriad Powers")

def getScaleTable(steps = 2): #defaults out to a great myriad, such that "steps" is equal to one myriad
    headers = ["e", "Great Myriad Scale", "Conway-Weschler Short", "Conway-Weschler Long"]
    data = [["0", "<m>", "<s>", "<l>"]]


    #the first 8 powers of 10 are always incremented by one
    for i in range (1, 8, 1):
        data.append([str(i), "<m>", "<s>", "<l>"])

    # Start from 8 increment by four powers of 10 to 100, skip to 200, 400,
    #(then 404 to clarifiy how the in betweeners are counted)
    #then, starting from 800 and do what was just done from 8, scaled by a factor of 100, until 100^steps
    t = 1
    while t < 100 ** steps:
        for i in range (8 * t, 104 * t, 4 * t):
            data.append([str(i), "<m>", "<s>", "<l>"])
        for i in range (200 * t, 600 * t, 200 * t):
            data.append([str(i), "<m>", "<s>", "<l>"])
        data.append([str(i + (4)), "<m>", "<s>", "<l>"])
        t *= 100
    return tablegen(headers, data, "Table of Scales")
    # this took awhile



def getScaleTableShort(steps = 2): #defaults out to a great myriad, such that "steps" is equal to one myriad
    headers = ["e", "Great Myriad Scale", "Conway-Weschler Short"]
    data = [["0", "<m>", "<s>"]]

    #the first 8 powers of 10 are always incremented by one
    for i in range (1, 8, 1):
        data.append([str(i), "<m>", "<s>"])

    # Start from 8 increment by four powers of 10 to 100, skip to 200, 400,
    #(then 404 to clarifiy how the in betweeners are counted)
    #then, starting from 800 and do what was just done from 8, scaled by a factor of 100, until 100^steps
    t = 1
    while t < 100 ** steps:
        for i in range (8 * t, 104 * t, 4 * t):
            data.append([str(i), "<m>", "<s>"])
        for i in range (200 * t, 600 * t, 200 * t):
            data.append([str(i), "<m>", "<s>"])
        data.append([str(i + (4)), "<m>", "<s>"])
        t *= 100
    return tablegen(headers, data, "Great Myriad v Short Scale")
    # this took awhile





def getScaleTableLong(steps = 2): #defaults out to a great myriad, such that "steps" is equal to one myriad
    headers = ["e", "Great Myriad Scale", "Conway-Weschler Long"]
    data = [["0", "<m>", "<l>"]]

    #the first 8 powers of 10 are always incremented by one
    for i in range (1, 8, 1):
        data.append([str(i), "<m>", "<l>"])

    # Start from 8 increment by four powers of 10 to 100, skip to 200, 400,
    #(then 404 to clarifiy how the in betweeners are counted)
    #then, starting from 800 and do what was just done from 8, scaled by a factor of 100, until 100^steps
    t = 1
    while t < 100 ** steps:
        for i in range (8 * t, 104 * t, 4 * t):
            data.append([str(i), "<m>", "<l>"])
        for i in range (200 * t, 600 * t, 200 * t):
            data.append([str(i), "<m>", "<l>"])
        data.append([str(i + (4)), "<m>", "<l>"])
        t *= 100
    return tablegen(headers, data, "Great Myriad v Long Scale")
    # this took awhile




def getCustomTable(arr):
        headers = ["e", "Great Myriad Scale", "Conway-Weschler Short", "Conway-Weschler Long"]
        data = []
        for e in arr:
            data.append([str(e), "<m>", "<s>", "<l>"])
        return tablegen(headers, data, "")

def tablegen(headers , data, title = ""):
        #data is a 2d array and headers is a 1d array

        # I want this to be able to parse a tag and replace it with something
        # A tag looks like <this>

        i = 0
        j = 0
        while i < len(data): #for i in data does not work
            j = 0
            while j < len(data[i]):
                if data[i][j][0] == "<": #j is a tag
                    #print(data[i][j])
                    if headers[j - 1] == "e":
                        data[i][j] = tagparse(data[i][j] + data[i][j - 1]) #table 1 is actually an edge case
                    else:
                        data[i][j] = tagparse(data[i][j] + data[i][0])

                    #print(data[i][j])
                j += 1
                #print(i, j)
            i += 1

        # Generate Markdown table
        markdown_table = tabulate(data, headers, tablefmt="pipe", stralign="left")
        return "\n"+ title + "\n\n" +  markdown_table

def tagparse(tag):
    type = tag[1]
    n = tag.strip("<" + tag[1] + ">")

    #print("n = " + str(n))

    if type == "m":
        return myriad.main(n, False, False) #n, prints off
    if type == "s":
        return million.main(n, True, False) #n, short scale, prints off
    if type == "l":
        return million.main(n, False, False)  #n, long scale, prints off
    return -1
if (__name__ == "__main__"):
    main()
